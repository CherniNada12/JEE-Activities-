package com.idsd.projetinjectiondependances;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetInjectionDependancesApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.idsd.projetinjectiondependances;

public interface IMetier {
    double calcul();
}

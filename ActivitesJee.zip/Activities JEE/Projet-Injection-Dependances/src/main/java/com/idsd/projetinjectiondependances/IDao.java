package com.idsd.projetinjectiondependances;

public interface IDao {
    double getData();
}
